<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>IPDC FORM EVALUASI</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="<?php echo base_url('assets/form/css/bootstrap.css')?>" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo base_url('assets/form/css/font-awesome.css')?>" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo base_url('assets/form/css/custom.css')?>" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        
      
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    <center><h1>IPDC</h1></center>
                     <center><h2>Forms Evaluasi</h2></center>   
                        
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               <div class="row">
                <div class="col-md-6">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                              
                        </div>
                       <div class="panel-body">
                        <?=$this->session->flashdata('pesan')?>
                          <form action="http://localhost/LaundrySepatu/FormEval/Welcome/insert" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-9">
                                    <h3>Form Data Diri</h3>
                                    <?php echo $v_user; ?>
                                        <?php echo $pil_training; ?>
                                    
                                    <br />

                                </div> 
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-success " name='finish' value='Lanjut'>Proses</button>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                    
                     <!-- End Form Elements -->
                </div>
               
            </div>
            


            
                <!-- /. ROW  -->
    </div>
             <!-- /. PAGE INNER  -->
            
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/jquery-1.10.2.js')?>"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/bootstrap.min.js')?>"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/jquery.metisMenu.js')?>"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/custom.js')?>"></script>
    
   
</body>
</html>
