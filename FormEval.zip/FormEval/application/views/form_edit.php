﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>IPDC FORM EVALUASI</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="<?php echo base_url('assets/form/css/bootstrap.css')?>" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo base_url('assets/form/css/font-awesome.css')?>" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo base_url('assets/form/css/custom.css')?>" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js" type="text/javascript"></script>
    
</head>
<body>
    <div id="wrapper">
        <form name="form1" id="form1" role="form" action="http://localhost/LaundrySepatu/FormEval/Welcome/input_form" method="POST">
      
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    <center><h1>IPDC</h1></center>
                     <center><h2>Forms Evaluasi</h2></center>   
                        
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               <div class="row">
                <div class="col-md-6">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form Element Examples
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-9">
                                    <h3>Form Data Diri</h3>
                                    <form role="form">
                                        <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input readonly class="form-control" name="nama_user" value="<?php echo $nama_user; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Training</label>
                                            <input readonly class="form-control" name="judul_materi" value="<?php echo $judul_materi; ?>"
                                            </select>
                                        </div>

                                        
                                    </form>
                                    <br />
                                </div>
                                
                                <?php echo $tanya_training; ?>

                            </div>
                        
                        </div>
                    </div>
                     <!-- End Form Elements -->
                </div>
                <?php 
                    if($jum_instruk==1){ ?>
                <div class="col-md-6" id="instruktur">    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Kuesioner Instruktur
                            </div>
                            <div class="panel-body">
                            <div class="row">    
                                <?php echo $instruktur; ?>
                            </div>
                            <div class="row">

                                <?php echo $tanya_instruktur; ?>
                            </div>
                            
                            </div>
                            
           
                        </div>

                        </div>

                <?php 
                    } 
                 
                    else{ ?> 
                        <div class="col-md-6" id="instruktur">    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Kuesioner Instruktur
                            </div>
                            <div class="panel-body">
                            <div class="row">    
                                <?php echo $instruktur; ?>
                            </div>
                            <div class="row">

                                <?php echo $tanya_instruktur; ?>
                            </div>
                            
                            </div>
                            
           
                        </div>

                        </div>
                        <div class="col-md-6" id="instruktur">    
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Kuesioner Instruktur
                            </div>
                            <div class="panel-body">
                            <div class="row">    
                                <?php echo $instruktur2; ?>
                            </div>
                            <div class="row">

                                <?php echo $tanya_instruktur2; ?>
                            </div>
                            
                            </div>
                            
           
                        </div>

                        </div>   
                <?php 
                    } ?>    

            </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-12">
                        <center><button type="submit" class="btn btn-success btn-lg">SUBMIT</button></center>
                    </div>
                </div>
    <!-- /. ROW  -->
    </div>
             <!-- /. PAGE INNER  -->
         </form>   
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    
    <script src="<?php echo base_url('assets/form/js/jquery-1.10.2.js')?>"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/bootstrap.min.js')?>"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/jquery.metisMenu.js')?>"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="<?php echo base_url('assets/form/js/custom.js')?>"></script>
    
   
</body>
</html>
