<div class="form-group">
                                            
                                            <label>Nama Lengkap</label>
                                            <input class="form-control" name="nama_user" required="required" placeholder="Masukan Nama lengkap" />
                                        </div>