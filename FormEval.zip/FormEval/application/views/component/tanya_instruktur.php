<?php
  foreach($data_insert as $d){ ?>
  
<div class="col-md-8">
                                    
                                    <div class="form-group">

                                            <label><?php echo $d['isi_pertanyaan_i'];?></label>
                                            <input type="hidden" class="form-control" name="id_pertanyaan_i[]" value="<?php echo $d['id_pertanyaan_i'];?>"/>
                                        </div>

                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" required="required" name="nilai_i<?php echo $d['id_pertanyaan_i'];?>[]"  value="1"/>STS &nbsp; &nbsp;
                                                    &nbsp; <input type="radio" name="nilai_i<?php echo $d['id_pertanyaan_i'];?>[]"  value="2"/>TS &nbsp; &nbsp;
                                                    &nbsp; <input type="radio" name="nilai_i<?php echo $d['id_pertanyaan_i'];?>[]"  value="3"/>S &nbsp; &nbsp;
                                                    &nbsp; <input type="radio" name="nilai_i<?php echo $d['id_pertanyaan_i'];?>[]" value="4"/>SS
                                                </label>
                                            </div>
                                            
                                    </div>
                                </div>
                               
<?php 
    } ?>  