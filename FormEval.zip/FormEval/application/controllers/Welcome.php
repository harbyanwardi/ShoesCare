<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct()
	{
		 parent::__construct();
         $this->load->helper('form','url');
		 $this->load->model('M_eval');

	}

	public function index()
	{
		$data = array();
		$data_insert = array(
							'pil_training' => $this->pil_training(),
							'v_user' => $this->v_user()
			);
		$this->load->view('form_awal',$data_insert);
	}
	
	public function insert()
	{
		
		$nama_user = $_POST['nama_user'];
		$judul_materi = $_POST['judul_materi'];
		if($nama_user=='' || $judul_materi==''){
			echo "gagal";
		}
		else{
		$cek_instrukturjumlah = $this->M_eval->GetData("tr_materi ","where judul_materi = '$judul_materi'");
		
		$jum_instruk = $cek_instrukturjumlah[0]['jum_instruktur'];
			$data_insert = array(
				'nama_user' => $nama_user,	
				'instruktur'=> $this->instruktur(),
				'instruktur2'=> $this->instruktur2(),
				'jum_instruk' => $jum_instruk,			
				'tanya_instruktur' => $this->tanya_instruktur(),
				'tanya_instruktur2' => $this->tanya_instruktur2(),
				'tanya_training' => $this->tanya_training(),
				'judul_materi' => $judul_materi
				);

			$data = array(
						'nama_user' => $nama_user,
				);
			$res = $this->M_eval->InsertData('tr_user',$data);
			$this->load->view('form_edit',$data_insert);
		}

	}
	
	public function input_form()
	{

		$nama_user = $_POST['nama_user'];		
		$cek_user = $this->M_eval->GetData("tr_user ","where nama_user = '$nama_user'");
		$id_user = $cek_user[0]['id_user'];
		$judul_materi = $_POST['judul_materi'];
		$cek_instrukturjumlah = $this->M_eval->GetData("tr_materi ","where judul_materi = '$judul_materi'");		
		$jum_instruk = $cek_instrukturjumlah[0]['jum_instruktur'];
		$cek_materi = $this->M_eval->GetData("tr_materi ","where judul_materi = '$judul_materi'");
		$id_materi = $cek_materi[0]['id_materi'];
		$cekdata = $this->M_eval->Hitung("mst_pertanyaan ","where kategori_pertanyaan = 't'");
		$cekdata_i = $this->M_eval->Hitung("pertanyaan_ins ","where kategori_pertanyaan = 'i'");
		$data_insert = array('data_insert'=> $this->M_eval->GetData("mst_pertanyaan ","where kategori_pertanyaan = 't'"));
		for($i=0;$i<$cekdata;$i++){
			$id_pertanyaan = $_POST['id_pertanyaan'][$i];
			$nilai_t = $_POST['nilai_t'.$id_pertanyaan];
			
				$nilai_tt = implode(" ",$nilai_t);
			
			
			$data_training = array(
				'id_user' => $id_user,	
				'id_materi'=> $id_materi,
				'id_pertanyaan' => $id_pertanyaan,
				'nilai_t' => $nilai_tt
				);
			
			$res_t = $this->M_eval->InsertData('nilai_training',$data_training);
		}
		if($jum_instruk==2){
		$id_instruktur = $_POST['id_instruktur'];
		$id_instruktur2 = $_POST['id_instruktur2'];

				for($d=0;$d<$cekdata_i;$d++){
					$id_pertanyaan_i = $_POST['id_pertanyaan_i'][$d];
					$nilai_i = $_POST['nilai_i'.$id_pertanyaan_i];
					$nilai_ii = implode(" ",$nilai_i);
					
					
					$data_instruktur = array(
						'id_user' => $id_user,	
						'id_instruktur'=> $id_instruktur,
						'id_pertanyaan_i' => $id_pertanyaan_i,
						'nilai_i' => $nilai_ii
						);
					$res_i = $this->M_eval->InsertData('nilai_instruktur',$data_instruktur);
				}
			
				for($d=0;$d<$cekdata_i;$d++){
					$id_pertanyaan_i = $_POST['id_pertanyaan_i'][$d];
					$nilai_i2 = $_POST['nilai_i2'.$id_pertanyaan_i];
					$nilai_ii = implode(" ",$nilai_i2);
					
					
					$data_instruktur = array(
						'id_user' => $id_user,	
						'id_instruktur'=> $id_instruktur2,
						'id_pertanyaan_i' => $id_pertanyaan_i,
						'nilai_i' => $nilai_ii
						);
					$res_i = $this->M_eval->InsertData('nilai_instruktur',$data_instruktur);
					
				}
			
		}
		else{
			$id_instruktur = $_POST['id_instruktur'];
			for($d=0;$d<$cekdata_i;$d++){
					$id_pertanyaan_i = $_POST['id_pertanyaan_i'][$d];
					$nilai_i = $_POST['nilai_i'.$id_pertanyaan_i];
					$nilai_ii = implode(" ",$nilai_i);
					
					
					$data_instruktur = array(
						'id_user' => $id_user,	
						'id_instruktur'=> $id_instruktur,
						'id_pertanyaan_i' => $id_pertanyaan_i,
						'nilai_i' => $nilai_ii
						);
					$res_i = $this->M_eval->InsertData('nilai_instruktur',$data_instruktur);
				}
		}

		$isi_saran = $_POST['isi_saran'];		
		$data_saran = array(
				'id_user' => $id_user,
				'id_materi' => $id_materi,
				'isi_saran' => $isi_saran		
			);
		$res_saran = $this->M_eval->InsertData('tr_saran',$data_saran);
		$this->flashdata_succeed();
	}
	
	
	public function instruktur(){
		$data_insert = array('data_insert'=> $this->M_eval->GetData('tr_instruktur'));
		$show = $this->load->view('component/instruktur',$data_insert,TRUE);
		return $show;
	}
	public function instruktur2(){
		$data_insert = array('data_insert'=> $this->M_eval->GetData('tr_instruktur'));
		$show = $this->load->view('component/instruktur2',$data_insert,TRUE);
		return $show;
	}
	public function pil_training(){
		$data_insert = array('data_insert'=> $this->M_eval->GetData('tr_materi'));
		$show = $this->load->view('component/pil_training',$data_insert,TRUE);
		return $show;
	}
	public function v_user(){
		$data_insert = array('data_insert'=> $this->M_eval->GetData('tr_user'));
		$show = $this->load->view('component/v_user',$data_insert,TRUE);
		return $show;
	}

	public function tanya_instruktur(){
		
		$data_insert = array('data_insert'=> $this->M_eval->GetData("pertanyaan_ins ","where kategori_pertanyaan = 'i'"));

		$show = $this->load->view('component/tanya_instruktur',$data_insert,TRUE);
		return $show;
	}
	public function tanya_instruktur2(){
		
		$data_insert = array('data_insert'=> $this->M_eval->GetData("pertanyaan_ins ","where kategori_pertanyaan = 'i'"));

		$show = $this->load->view('component/tanya_instruktur2',$data_insert,TRUE);
		return $show;
	}
	public function tanya_training(){
		
		$data_insert = array('data_insert'=> $this->M_eval->GetData("mst_pertanyaan ","where kategori_pertanyaan = 't'"));

		$show = $this->load->view('component/tanya_training',$data_insert,TRUE);
		return $show;
	}

	public function flashdata_failed(){
        $this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-danger\" id=\"alert\">Isi form secara lengkap !!!</div></div>");
                redirect('Welcome/index');
    }
    
    public function flashdata_succeed(){
        $this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-success\" id=\"alert\">Input Form Kuesioner Berhasil !</div></div>");
        	redirect('http://localhost/LaundrySepatu/FormEval/Welcome/index');
                
    }

	
}
